﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace m_project2
{
    public class Chemistry:Lesson
    {
        public List<string> chemicals;
    }
}
