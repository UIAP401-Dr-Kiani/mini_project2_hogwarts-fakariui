﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace m_project2
{
    public class Phytology:Lesson
    {
        public List<Plant> plant1;
        public List<Plant> plant2;
        public List<Plant> plant3;
        public List<Plant> plant4;
    }
}
